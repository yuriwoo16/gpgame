# Test Variant Site

Static GitHub Pages site for `test-variant.html`.

## Build

```bash
npm run build
```

The build copies `test-variant.html` to `dist/index.html`.
